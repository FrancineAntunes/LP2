﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[3,4];
            double totalMes = 0.00 ;
            double totalGeral= 0.00 ;
            string aux;
            double valSemana = 0.00;
            string separador = "-----------------------------------------------";
            for (int mes = 0; mes < 3; mes++)
            {
                totalMes = 0.0;
                for (int semana = 0; semana < 4; semana++)
                {
                    aux = Interaction.InputBox($"Digite o valor referente ao {mes + 1}º mês, na {semana + 1}° semana:", "Entrada de dados");
                    if (!double.TryParse(aux, out vetor[mes, semana] ))
                    {
                        MessageBox.Show("Insira um valor válido");
                        semana--;
                    }
                    valSemana = Convert.ToDouble(aux);
                    lstbxResultado.Items.Add($"Total do mês:{mes + 1} Semana:{semana + 1} {aux}");
                    totalMes += valSemana;
                }
                lstbxResultado.Items.Add($">> Total Mês:R${totalMes}");
                lstbxResultado.Items.Add(separador);
                totalGeral += totalMes;
            }
            lstbxResultado.Items.Add($">> Total Geral:R${totalGeral}");
        }
    }
}
