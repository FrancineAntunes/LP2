﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class PSalario : Form
    {
        double salarioBruto, salarioLiquido, salarioFamilia, descontoINSS, descontoIRPF, nFilhos;

        private void NudFilhos_Validated(object sender, EventArgs e)
        {
            nFilhos = Convert.ToDouble(NudFilhos.Value);
        }

        private void mskSalarioBruto_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskSalarioBruto.Text, out salarioBruto)) || (salarioBruto == 0))
            {
                MessageBox.Show("Salário inválido");
                mskSalarioBruto.Focus();

            }
        }

        public PSalario()
        {
            InitializeComponent();
        }

        private void txtFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void btnVerDesconto_Click(object sender, EventArgs e)
        {
           if (salarioBruto <= 800.47)
            {
                txtAliINSS.Text = "7,65%";
                descontoINSS = 0.0765 * salarioBruto;
                txtDescontoINSS.Text = descontoINSS.ToString("N2");
            }
           else if (salarioBruto <= 1050)
                {
                    txtAliINSS.Text = "8,65%";
                    descontoINSS = 0.0865 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");
                }
            else if (salarioBruto <= 1400.77)
            {
                txtAliINSS.Text = "9,00%";
                descontoINSS = 0.09 * salarioBruto;
                txtDescontoINSS.Text = descontoINSS.ToString("N2");
            }
            else if (salarioBruto <= 2801.56)
            {
                txtAliINSS.Text = "11,00%";
                descontoINSS = 0.11 * salarioBruto;
                txtDescontoINSS.Text = descontoINSS.ToString("N2");
            }
            else
            {
                txtAliINSS.Text = "Teto";
                descontoINSS = 308.17;
                txtDescontoINSS.Text = descontoINSS.ToString("N2");
            }

            if (salarioBruto <= 1257.12)
            {
                txtAliIRPF.Text = "Isento";
                descontoIRPF = 0;
                txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
            }
            else if (salarioBruto <= 2512.08)
            {
                txtAliIRPF.Text = "15%";
                descontoIRPF = 0.15 * salarioBruto;
                txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
            }
            else
            {
                txtAliIRPF.Text = "27,5%";
                descontoIRPF = 0.275 * salarioBruto;
                txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
            }
            if (salarioBruto <= 435.52)
            {
                salarioFamilia = 22.33 * nFilhos;
                txtSalFamilia.Text = salarioFamilia.ToString("N2");
            }
            else if (salarioBruto <= 654.61)
            {
                salarioFamilia = 15.74 * nFilhos;
                txtSalFamilia.Text = salarioFamilia.ToString("N2");
            }
            else
            {
                salarioFamilia = 0 * nFilhos;
                txtSalFamilia.Text = salarioFamilia.ToString("N2");
            }

            salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
            txtSalLiquido.Text = salarioLiquido.ToString("N2");
        }
    }
}
