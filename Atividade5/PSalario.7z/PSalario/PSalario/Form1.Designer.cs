﻿namespace PSalario
{
    partial class PSalario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PSalario));
            this.btnVerDesconto = new System.Windows.Forms.Button();
            this.txtDescontoIRPF = new System.Windows.Forms.TextBox();
            this.txtFunc = new System.Windows.Forms.TextBox();
            this.txtDescontoINSS = new System.Windows.Forms.TextBox();
            this.txtAliINSS = new System.Windows.Forms.TextBox();
            this.txtAliIRPF = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.mskSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.NudFilhos = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.NudFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // btnVerDesconto
            // 
            this.btnVerDesconto.BackColor = System.Drawing.SystemColors.Control;
            resources.ApplyResources(this.btnVerDesconto, "btnVerDesconto");
            this.btnVerDesconto.Name = "btnVerDesconto";
            this.btnVerDesconto.UseVisualStyleBackColor = false;
            this.btnVerDesconto.Click += new System.EventHandler(this.btnVerDesconto_Click);
            // 
            // txtDescontoIRPF
            // 
            resources.ApplyResources(this.txtDescontoIRPF, "txtDescontoIRPF");
            this.txtDescontoIRPF.Name = "txtDescontoIRPF";
            // 
            // txtFunc
            // 
            this.txtFunc.AcceptsReturn = true;
            resources.ApplyResources(this.txtFunc, "txtFunc");
            this.txtFunc.Name = "txtFunc";
            this.txtFunc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFunc_KeyPress);
            // 
            // txtDescontoINSS
            // 
            resources.ApplyResources(this.txtDescontoINSS, "txtDescontoINSS");
            this.txtDescontoINSS.Name = "txtDescontoINSS";
            // 
            // txtAliINSS
            // 
            resources.ApplyResources(this.txtAliINSS, "txtAliINSS");
            this.txtAliINSS.Name = "txtAliINSS";
            // 
            // txtAliIRPF
            // 
            resources.ApplyResources(this.txtAliIRPF, "txtAliIRPF");
            this.txtAliIRPF.Name = "txtAliIRPF";
            // 
            // txtSalLiquido
            // 
            resources.ApplyResources(this.txtSalLiquido, "txtSalLiquido");
            this.txtSalLiquido.Name = "txtSalLiquido";
            // 
            // txtSalFamilia
            // 
            resources.ApplyResources(this.txtSalFamilia, "txtSalFamilia");
            this.txtSalFamilia.Name = "txtSalFamilia";
            // 
            // mskSalarioBruto
            // 
            this.mskSalarioBruto.AllowPromptAsInput = false;
            resources.ApplyResources(this.mskSalarioBruto, "mskSalarioBruto");
            this.mskSalarioBruto.Name = "mskSalarioBruto";
            this.mskSalarioBruto.Validated += new System.EventHandler(this.mskSalarioBruto_Validated);
            // 
            // NudFilhos
            // 
            resources.ApplyResources(this.NudFilhos, "NudFilhos");
            this.NudFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.NudFilhos.Name = "NudFilhos";
            this.NudFilhos.Validated += new System.EventHandler(this.NudFilhos_Validated);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // PSalario
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NudFilhos);
            this.Controls.Add(this.mskSalarioBruto);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtAliIRPF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.txtDescontoINSS);
            this.Controls.Add(this.txtFunc);
            this.Controls.Add(this.txtDescontoIRPF);
            this.Controls.Add(this.btnVerDesconto);
            this.Name = "PSalario";
            ((System.ComponentModel.ISupportInitialize)(this.NudFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerDesconto;
        private System.Windows.Forms.TextBox txtDescontoIRPF;
        private System.Windows.Forms.TextBox txtFunc;
        private System.Windows.Forms.TextBox txtDescontoINSS;
        private System.Windows.Forms.TextBox txtAliINSS;
        private System.Windows.Forms.TextBox txtAliIRPF;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.MaskedTextBox mskSalarioBruto;
        private System.Windows.Forms.NumericUpDown NudFilhos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

