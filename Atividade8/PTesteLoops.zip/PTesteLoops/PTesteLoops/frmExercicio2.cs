﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnH_Click(object sender, EventArgs e)
        {
            string inputN = txtN.Text;
            double N;

            if (double.TryParse(inputN, out N))
            {
                if (N == 0)
                {
                    MessageBox.Show("Números inválidos: N não pode ser igual a 0.");
                }
                else
                {
                    double H = 1;

                    for (double i = 2; i <= N; i++)
                    {
                        H += 1 /  i;
                    }
                    MessageBox.Show($"O H será: {H}.");
                }
            }
        }
    }
}
    

