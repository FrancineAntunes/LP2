﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio4 : Form
    {
        double salario, salBruto, prod, grat;
        int B = 0, C = 0, D = 0;

        private void txtMat_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter Inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtGrat_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter Inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }


        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtMat.Clear();
            txtProd.Clear();
            txtGrat.Clear();
            mskSalario.Clear();
        }

        private void mskSalario_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse( mskSalario.Text, out salario) || (salario == 0 ))
            {
                MessageBox.Show("Insira um valor válido");
                mskSalario.Focus();
            }
        }

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtProd.Text, out prod) &&
                double.TryParse(txtGrat.Text, out grat))
            {
                if (prod >= 150)
                {
                    B = 1;
                    C = 1;
                    D = 1;
                    salBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + grat;
                }
                else if (prod >=120)
                {
                    B = 1;
                    C = 1;
                    salBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + grat;
                }
                else if (prod >=100)
                {
                    B = 1;
                    salBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + grat;
                }
                else
                {
                    salBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + grat;
                }
                if (salBruto>7000 && grat ==0 || prod < 150)
                {
                    salBruto = 7000;
                }
                MessageBox.Show($"O Salário Bruto é : {salBruto}");
            }
        }
    }
}
