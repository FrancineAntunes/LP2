﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPali_Click(object sender, EventArgs e)
        {
            string PaliMaius = txtPali.Text.ToUpper();
            string Pali = PaliMaius.Replace(" ", "");
            char[] Vetor = Pali.ToCharArray();
            Array.Reverse(Vetor);
            string PaliPost = new String(Vetor);

            if (String.Compare(Pali, PaliPost, true) == 0)
                MessageBox.Show("É um Palíndromo!");
            else
                MessageBox.Show("Não é um Palíndromo!");
        }
    }
}
