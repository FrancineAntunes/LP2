﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;
            int contador = 0;
            foreach (char caracter in texto)
            {
                if (char.IsWhiteSpace(caracter))
                {
                    contador++;
                }
            }
            MessageBox.Show($"A quantidade de espaços em branco é: {contador}");
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            char caracter = 'R';
            int quantidade = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (char.ToUpper(frase[i]) == char.ToUpper(caracter))
                {
                  quantidade++;
                }
            }
            MessageBox.Show($"A quantidade de '{caracter}' na frase é: {quantidade}");
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            int contador = 0;

            for (int i = 0; i < frase.Length - 1; i++)
            {
                if (frase[i] == frase[i + 1])
                {
                    contador++;
                }
            }

            MessageBox.Show($"A quantidade de pares de letra na frase é: {contador}");
        }
    }
}
