﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtAltura.Text, out altura)) || (altura <= 0))
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
                         
         
        }

        private void txtIMC_Validated(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            txtIMC.Text = imc.ToString();
            if (imc < 18.5)
                MessageBox.Show("Magreza");
            else if (imc <= 24.9)
                MessageBox.Show("Normal");
            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso");
            else if (imc <= 39.9)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade grave");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtIMC.Clear();
            txtPeso.Clear();

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtPeso.Text,out peso)) || (peso <= 0))
            {
                MessageBox.Show("Peso inválido");
                txtPeso.Focus();
            }
     
        }
    }
}
