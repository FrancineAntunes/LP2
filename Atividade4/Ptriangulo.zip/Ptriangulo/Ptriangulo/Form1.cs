﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;
        string TipoTriangulo;

        private void txtValB_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtValB.Text, out valorB))
            {
                MessageBox.Show("Valor B inválido!");
                txtValB.Focus();
            }

            if ((!double.TryParse(txtValB.Text, out valorB)) || (valorB <= 0))
            {
                MessageBox.Show("Valor de B inválido");
                txtValB.Focus();
            }
        }

        private void txtValC_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtValC.Text, out valorC))
            {
                MessageBox.Show("Valor C inválido!");
                txtValC.Focus();
            }

            if ((!double.TryParse(txtValC.Text, out valorC)) || (valorC <= 0))
            {
                MessageBox.Show("Valor de C inválido");
                txtValC.Focus();
            }
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            if ((valorA < (valorB + valorC) && valorA > (valorB - valorC) && valorB < (valorA + valorC) && valorB > (valorA - valorC) && valorC < (valorA + valorB) && valorC > (valorA - valorB)))
            {

                MessageBox.Show("Os valores são válidos. Formam um triângulo!");


            }
            else
            {
                MessageBox.Show("Os valores não são válidos. Não formam um triângulo!");
            }


            if (valorA == valorB && valorB == valorC)
            {

                TipoTriangulo = "Equilátero!";
                txtTipo.Text = TipoTriangulo;

            }
            else if (valorA == valorB && valorB != valorC)
            {

                TipoTriangulo = "Isósceles!";
                txtTipo.Text = TipoTriangulo;

            }
            else if (valorA != valorB && valorB != valorC)
            {

                TipoTriangulo = "Escaleno!";
                txtTipo.Text = TipoTriangulo;
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Realmente deseja sair ?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)

                Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValA_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtValA.Text, out valorA))
            {
                MessageBox.Show("Valor A inválido!");
                txtValA.Focus();
            }
            if ((!double.TryParse(txtValA.Text, out valorA)) || (valorA <= 0))
            {
                MessageBox.Show("Valor de A inválido");
                txtValA.Focus();
            }
        }
    }
}
