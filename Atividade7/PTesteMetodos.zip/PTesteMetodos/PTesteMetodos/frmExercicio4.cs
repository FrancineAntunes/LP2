﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;
            int contNumber = 0;
            int contador = 0;
            string numero;
            while (contador < texto.Length) 
            {
                if (char.IsNumber(texto[contador]))
                {
                    contNumber++;
                }
                contador++;
            }
            numero = contNumber.ToString();
            MessageBox.Show($"O número de caracteres numéricos são: {numero}");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;
            int posicao = 0;
            int contador = 0;
            while (contador < texto.Length)
            {
                if (char.IsWhiteSpace(texto[contador]))
                {
                    posicao = contador;
                }
                contador++;
            }
            posicao++;
            MessageBox.Show($"A posição do 1º espaço em branco é: {posicao}");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;
            int numero = 0;
            foreach (char letra in texto) 
            {
                if ((Char.IsLetter(letra)))
                {
                    numero++;
                }
            }
            MessageBox.Show("Há " + numero + " caracteres alfabéticos.");
        }
    }
}
