﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            double Num1, Num2, Resultado;
            if((!double.TryParse(txtNumero1.Text, out Num1) || 
            (!double.TryParse(txtNumero2.Text, out Num2) ||(Num1>Num2))))
            {
                MessageBox.Show("Números Inválidos");
            }
            else
            {
                Random objR = new Random();
                Resultado = objR.Next((int)Num1, (int)Num2);
                MessageBox.Show(Resultado.ToString());
            }
        }
    }
}
