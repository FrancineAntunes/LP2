﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;


namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for(int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1} número", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Insira valor válido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";

            foreach(int x in vetor)
                auxiliar += x + "\n";
            MessageBox.Show(auxiliar);

        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList Nomes = new ArrayList() {"Ana","André","Débora","Fátima","João","Janete","Otávio","Marcelo","Pedro","Thais"};
            string auxiliar = "";
            Nomes.Remove("Otávio");

            foreach(string x in Nomes) 
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double [,] notas = new double[20, 3];
            string aux = "";
            double media = 0;
            string saida = "";

            for(int aluno = 0; aluno < 20; aluno++)
            {
                media = 0;
                for(int nota = 0; nota < 3;nota++)
                {
                    aux = Interaction.InputBox($"Digite a nota {nota + 1}, do aluno {aluno + 1}", "Entrada de dados");

                    if(!double.TryParse(aux, out notas[aluno,nota]))
                    {
                        MessageBox.Show("Insira um valor válido");
                        nota--;
                    }
                    else
                    {
                        media += notas[aluno, nota];
                    }

                }
                media = media / 3;
                saida += ($"Aluno: {aluno + 1}, media: {media}" + "\n");
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 obj1 = new frmExercicio4();
                obj1.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj1 = new frmExercicio5();
                obj1.Show();
            }
        }
    }
}
