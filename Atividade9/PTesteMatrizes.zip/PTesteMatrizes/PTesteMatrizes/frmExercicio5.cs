﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            char[] gabarito = { 'E', 'D', 'C', 'B', 'A', 'A', 'B', 'C', 'D', 'E' };
            char[,] provaAlunos = new char[4, 10];
            string refGabarito = "Gabarito: E, D, C, B, A, A, B, C, D, E";

            for (int aluno = 0; aluno < 4; aluno++)
            {
                string aux = $"Aluno {aluno + 1}:";
                int nota = 0;

                for (int resp = 0; resp < 10; resp++)
                {
                    char resposta;
                    do
                    {
                        resposta = Interaction.InputBox($"Digite sua resposta da {resp + 1}º questão para o aluno {aluno + 1}", "Entrada de dados").ToUpper()[0];
                    } while (resposta < 'A' || resposta > 'E');

                    provaAlunos[aluno, resp] = resposta;
                    aux += $" {provaAlunos[aluno, resp]}";

                    if (provaAlunos[aluno, resp] == gabarito[resp])
                    {
                        nota++;
                    }
                }

                aux += $" acertou {nota} questões";
                listBoxResult.Items.Add(aux);
                listBoxResult.Items.Add(refGabarito);
            }
        }     
    }
}
