﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            string[] vetor = new string[3];
            string[] vetor2 = new string[3];
            int[] tam = new int[3];
            
            for (int i = 0; i < vetor.Length; i++)
            {
                vetor[i]= Interaction.InputBox($"Digite o nome do {i+1}º aluno", "Entrada de dados");
                vetor2[i] = vetor[i].Replace(" ", "");
                tam[i] = vetor2[i].Length;
            }

            for (int i = 0; i < vetor.Length; i++)
            {
                listBoxResult.Items.Add($"O nome {vetor[i]} tem {tam[i]} caracteres");
            }
        }
    }
}
